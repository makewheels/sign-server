package util;

/**
 * 常量
 * 
 * @author Administrator
 *
 */
public class Constants {
//	public static String BASEURL = "http://192.168.0.101/sign-app";
	public static String BASEURL = "https://qbserver.cn/sign-app";

	public static String APP_VERSION = "1.0.0";
	public static String ROOT_PATH = null;
}
